# E-Commerce Laravel : Tugas Sesi 10 - 23

## Deskripsi

Folder `ecommerce10` berisi proyek e-commerce berbasis Laravel yang dibangun secara bertahap mulai dari sesi 10 sampai sesi 23. Proyek mencakup setup Laravel dan MySQL, controller dan halaman Blade, migration dan seeder, relasi model, autentikasi, pengelolaan produk dan kategori, upload gambar, pembatasan akses admin, serta dashboard admin dengan metrik dan analitik yang dihitung dari data database, termasuk pelacakan klik produk dan ringkasan status pesanan.

README ini disusun per sesi agar riwayat pengerjaan mudah dibaca dan dapat diperbarui ketika ada tugas sesi berikutnya.

## Daftar Tugas

| Sesi | Topik | Fokus |
| --- | --- | --- |
| 10 | Laravel Basics & Project Introduction with AI | Setup proyek Laravel, route dasar, model, dan controller awal |
| 11 | Blade Templating & Controller Essentials | Controller untuk mengelola produk dan halaman |
| 12 | Dynamic Page Creation | Halaman Blade dinamis dan komponen navbar/footer |
| 13 | Database Migration & Dummy Data Using AI | Migration tabel dan seeder data dummy |
| 14 | Eloquent Relationship & Pagination | Relasi model Product/ProductCategory, data produk dari database, dan pagination |
| 15 | Authentication with Laravel Breeze | Instalasi Laravel Breeze, login, registrasi, dan kustomisasi tampilan bawaan |
| 16 | Admin Product & Category Management | Menu navigasi, tabel daftar kategori dan produk, serta tombol tambah, edit, dan hapus |
| 17 | Product & Category Create/Edit Forms | Form tambah/edit produk dan kategori, validasi, serta upload gambar produk |
| 18 | Dashboard Summary & Analytics | Ringkasan jumlah produk, kategori, dan klik produk, serta grafik dashboard |
| 19 | Role & Admin Middleware | Kolom role pada users, middleware admin, dan pembatasan akses route dashboard |
| 20 | Complete Back-End Product System | Form tambah produk dan kategori, route POST, validasi input, dan penyimpanan data ke database |
| 21 | Product Editing & Deletion System | Form edit produk, pembaruan data, serta penghapusan produk dan kategori |
| 22 | Final Dashboard Adjustments with AI | Penyesuaian Product Controller, pengelolaan edit/hapus kategori, dan penyempurnaan dashboard admin |
| 23 | Streamlined Back-End Finalization Using AI | Kolom dan pelacakan klik produk, DashboardController berbasis database, grafik jumlah pesanan, dan ringkasan status order |

## Tugas Sesi 10 : Laravel Basics & Project Introduction with AI

### Deskripsi

Membuat proyek Laravel baru untuk membangun website e-commerce, menyiapkan route dasar, mengonfigurasi database, serta membuat model dan controller awal untuk Product dan Order.

### Fitur

- Proyek Laravel baru dengan konfigurasi database MySQL.
- Route dasar: `/`, `/products`, `/cart`, dan `/checkout`.
- Route tambahan: `/shop`, `/product/{id}`, dan `/orders`.
- Model awal: `Product`, `ProductCategory`, `Cart`, `Order`, `OrderItem`, dan `User`.
- Controller awal untuk mengelola Product dan Order.
- Halaman katalog sementara menggunakan data dummy dari model `Product`.

### Dibangun Menggunakan

- Laravel 13
- PHP 8.3+
- MySQL

### File Terkait

```text
routes/web.php
app/Models/
app/Http/Controllers/
```

## Tugas Sesi 11 : Blade Templating & Controller Essentials

### Deskripsi

Menambahkan controller dasar untuk mengelola produk dan halaman, lalu memindahkan logika halaman dari route ke controller agar struktur aplikasi lebih rapi.

### Fitur

- `HomeController` untuk halaman utama, detail produk, dan keranjang.
- `ProductController` dan `ProductCategoryController` sebagai resource controller untuk pengelolaan produk dan kategori.
- `CartController`, `OrderController`, dan `OrderItemController` untuk alur keranjang dan pesanan.
- Route halaman diarahkan ke controller dan diberi nama route.

### Dibangun Menggunakan

- Laravel 13
- PHP 8.3+

### File Terkait

```text
app/Http/Controllers/HomeController.php
app/Http/Controllers/ProductController.php
app/Http/Controllers/ProductCategoryController.php
app/Http/Controllers/CartController.php
app/Http/Controllers/OrderController.php
app/Http/Controllers/OrderItemController.php
routes/web.php
```

## Tugas Sesi 12 : Dynamic Page Creation

### Deskripsi

Membuat halaman-halaman dinamis menggunakan Blade dan menampilkan data yang dikirim dari controller, serta memisahkan bagian tampilan yang berulang menjadi komponen Blade.

### Fitur

- Halaman utama dan daftar produk (`/`, `/shop`, `/products`) dengan grid kartu produk.
- Halaman detail produk (`/product/{id}`) dengan breadcrumb.
- Halaman keranjang belanja (`/cart`).
- Layout Blade yang dapat digunakan ulang oleh semua halaman.
- Komponen Blade untuk navbar, footer, product card, breadcrumb, dan alert.
- Styling menggunakan Tailwind CSS 4, aset shadcn HTML, ikon Lucide, dan Vite.

### Dibangun Menggunakan

- Laravel Blade
- Tailwind CSS 4
- Vite
- JavaScript (Lucide Icons)

### File Terkait

```text
resources/views/home/index.blade.php
resources/views/product/description.blade.php
resources/views/cart/index.blade.php
resources/views/components/header.blade.php
resources/views/components/footer.blade.php
resources/views/components/layout-component.blade.php
resources/views/components/product-card.blade.php
resources/views/components/breadcrumb.blade.php
resources/views/components/alert.blade.php
app/View/Components/
```

## Tugas Sesi 13 : Database Migration & Dummy Data Using AI

### Deskripsi

Membuat migration untuk struktur tabel e-commerce dan seeder untuk mengisi data dummy produk dan kategori agar halaman memiliki data awal yang dapat diuji.

### Fitur

- Migration tabel `product_categories`, `products`, `carts`, `orders`, dan `order_items`.
- Foreign key untuk menghubungkan produk dengan kategori, keranjang dengan pengguna/produk, serta pesanan dengan item pesanan.
- Seeder `ProductCategorySeeder` untuk 5 kategori: Headphone, Earbuds, Speaker, Smartwatch, dan Keyboard.
- Seeder `ProductSeeder` untuk 16 produk dummy dengan minimal 3 produk pada setiap kategori.
- `DatabaseSeeder` menjalankan seeder produk dan aman dijalankan berulang tanpa membuat data ganda.

Catatan: pada implementasi ini, detail produk dalam pesanan disimpan di tabel `order_items`, sehingga satu pesanan dapat memiliki lebih dari satu produk.

### Dibangun Menggunakan

- Laravel Migration
- Laravel Seeder
- Eloquent ORM
- MySQL

### File Terkait

```text
database/migrations/
├── 0001_01_01_000000_create_users_table.php
├── 0001_01_01_000001_create_cache_table.php
├── 0001_01_01_000002_create_jobs_table.php
├── 2026_10_23_135642_create_product_categories_table.php
├── 2026_10_23_135643_create_products_table.php
├── 2026_10_23_135644_create_carts_table.php
├── 2026_10_23_135645_create_orders_table.php
└── 2026_10_23_135646_create_order_items_table.php

database/seeders/
├── DatabaseSeeder.php
├── ProductCategorySeeder.php
└── ProductSeeder.php
```

## Tugas Sesi 14 : Eloquent Relationship & Pagination

![Thumbnail](.thumbnails/tugas_sesi_14_home.png)
![Thumbnail](.thumbnails/tugas_sesi_14_product_detail.png)

### Deskripsi

Menghubungkan model menggunakan relasi Eloquent, lalu menampilkan data produk dari database menggunakan controller dan Blade. Daftar produk dibatasi dengan pagination agar data yang tampil dalam satu halaman tetap rapi. Mulai sesi 14, proyek menggunakan database MySQL.

### Fitur

- Model `Product` dengan relasi `category()`, `carts()`, dan `orderItems()`, serta model `ProductCategory` dengan relasi `products()`.
- Relasi pendukung antar model: `Cart` ke `User`/`Product`/`Order`, `Order` ke `User`/`Cart`/`OrderItem`, `OrderItem` ke `Order`/`Product`, dan `User` ke `Cart`/`Order`.
- `HomeController@index` mengambil produk dari database dengan `paginate(8)` dan `withQueryString()`, mendukung filter kategori lewat query `?category=slug`, serta mengirim daftar kategori dengan jumlah produknya (`withCount('products')`).
- `ProductController@show` menampilkan detail produk berdasarkan route model binding beserta breadcrumb kategori.
- Halaman home menampilkan daftar kategori yang dapat diklik dan grid produk dengan komponen `product-card`.
- Pagination Tailwind pada halaman daftar produk.
- Data dummy hardcoded pada model `Product` dihapus dan diganti data dari database hasil seeder.
- Seeder produk menggunakan gambar berbeda untuk setiap kategori (headphone, earbuds, speaker, smartwatch, keyboard).

### Dibangun Menggunakan

- Eloquent ORM
- MySQL
- Route Model Binding
- Laravel Pagination
- Laravel Blade
- Tailwind CSS 4

### File Terkait

```text
app/Models/Product.php
app/Models/ProductCategory.php
app/Models/Cart.php
app/Models/Order.php
app/Models/OrderItem.php
app/Models/User.php
app/Http/Controllers/HomeController.php
app/Http/Controllers/ProductController.php
app/Http/Controllers/CartController.php
resources/views/home/index.blade.php
resources/views/product/description.blade.php
resources/views/vendor/pagination/tailwind.blade.php
resources/views/vendor/pagination/simple-tailwind.blade.php
database/seeders/ProductSeeder.php
routes/web.php
```

## Tugas Sesi 15 : Authentication with Laravel Breeze

![Thumbnail](.thumbnails/tugas_sesi_15_dashboard.png)
![Thumbnail](.thumbnails/tugas_sesi_15_login.png)
![Thumbnail](.thumbnails/tugas_sesi_15_register.png)

### Deskripsi

Menginstal Laravel Breeze untuk menambahkan fitur autentikasi seperti login dan registrasi, kemudian menyesuaikan file Blade bawaan Breeze agar sesuai dengan identitas aplikasi e-commerce ini. Fitur autentikasi ini menggunakan database MySQL yang sama dengan tugas sesi 14.

### Fitur

- Instalasi Laravel Breeze dengan stack Blade untuk fitur autentikasi.
- Halaman login, registrasi, lupa password, reset password, verifikasi email, dan konfirmasi password.
- Fitur logout, dashboard untuk pengguna yang sudah login, serta pengelolaan profil (ubah data profil, ubah password, dan hapus akun).
- Route autentikasi dipisahkan pada `routes/auth.php`, sedangkan route dashboard dan profil dilindungi middleware `auth` dan `verified`.
- Kustomisasi tampilan bawaan Breeze: logo aplikasi diganti ikon toko (Lucide `store`) dan nama situs menggunakan `config('app.name')` dengan nilai `Ecommerce`.
- Penyesuaian halaman `welcome`, layout guest, navigation bar, serta komponen Blade bawaan Breeze agar selaras dengan tema aplikasi.
- Dependency frontend Breeze: Alpine.js dan `@tailwindcss/forms`.
- Test fitur autentikasi dan profil dari Breeze.

### Dibangun Menggunakan

- Laravel Breeze 2
- Laravel Blade
- Alpine.js
- Tailwind CSS 4
- `@tailwindcss/forms`
- MySQL
- Vite

### File Terkait

```text
app/Http/Controllers/Auth/
app/Http/Controllers/ProfileController.php
app/Http/Requests/Auth/LoginRequest.php
app/Http/Requests/ProfileUpdateRequest.php
app/View/Components/AppLayout.php
app/View/Components/GuestLayout.php
app/Models/User.php
routes/auth.php
routes/web.php
resources/views/auth/
resources/views/layouts/
resources/views/profile/
resources/views/components/application-logo.blade.php
resources/views/dashboard.blade.php
resources/views/welcome.blade.php
resources/css/app.css
resources/js/app.js
tests/Feature/Auth/
tests/Feature/ProfileTest.php
```

## Tugas Sesi 16 : Admin Product & Category Management

![Thumbnail](.thumbnails/tugas_sesi_16_product-categories.png)
![Thumbnail](.thumbnails/tugas_sesi_16_products.png)

### Deskripsi

Menambahkan menu navigasi menuju halaman daftar kategori dan produk, lalu membuat halaman admin untuk menampilkan data produk dan kategori dalam bentuk tabel beserta tombol tambah, edit, dan hapus.

### Fitur

- Menu navigasi `Products` dan `Product Categories` pada navigation bar untuk pengguna yang sudah login.
- Route resource `products` dan `product-categories` di bawah prefix `/dashboard`, dilindungi middleware `auth` dan `verified`.
- Halaman daftar kategori menampilkan tabel berisi nama, slug, jumlah produk, total harga, dan total stok produk pada setiap kategori.
- Halaman daftar kategori menyediakan tombol `Create Category`, `View`, `Edit`, dan `Delete`.
- Halaman daftar produk menampilkan tabel berisi gambar, nama, harga, stok, kategori, dan deskripsi produk.
- Halaman daftar produk menyediakan tombol `Create Product`, `View`, `Edit`, dan `Delete`.
- Pencarian produk berdasarkan nama, filter berdasarkan kategori, serta pengurutan berdasarkan nama, harga, dan stok (naik/turun).
- Pagination 5 produk per halaman dan query filter tetap terbawa saat berpindah halaman.
- Perhitungan jumlah produk, total harga, dan total stok kategori menggunakan `withCount()` dan `withSum()`.
- Penyesuaian tampilan pagination Tailwind menggunakan style tombol aplikasi.

### Dibangun Menggunakan

- Laravel Resource Controller
- Eloquent ORM (`withCount`, `withSum`)
- MySQL
- Laravel Blade
- Tailwind CSS 4
- Lucide Icons

### File Terkait

```text
app/Http/Controllers/ProductController.php
app/Http/Controllers/ProductCategoryController.php
resources/views/admin/categories/index.blade.php
resources/views/admin/products/index.blade.php
resources/views/layouts/navigation.blade.php
resources/views/vendor/pagination/tailwind.blade.php
routes/web.php
```

## Tugas Sesi 17 : Product & Category Create/Edit Forms

![Thumbnail](.thumbnails/tugas_sesi_17_create_product_form.png)
![Thumbnail](.thumbnails/tugas_sesi_17_edit_product_form.png)
![Thumbnail](.thumbnails/tugas_sesi_17_create_product_category_form.png)
![Thumbnail](.thumbnails/tugas_sesi_17_edit_product_category_form.png)

### Deskripsi

Membuat form untuk menambah dan mengedit produk serta kategori produk. Form produk memiliki halaman tersendiri, sedangkan form kategori ditampilkan dalam dialog pada halaman daftar kategori. Setiap form dilengkapi validasi, pembuatan slug otomatis, dan upload gambar produk.

### Fitur

- Halaman tambah produk (`/dashboard/products/create`) dan edit produk (`/dashboard/products/{product}/edit`) menggunakan partial form yang sama.
- Field produk: nama, slug, deskripsi, kategori, harga, stok, dan gambar.
- Form tambah dan edit kategori berupa dialog pada halaman daftar kategori, dengan field nama dan slug.
- Validasi server-side: field wajib, slug produk/kategori unik, kategori harus ada, serta harga dan stok berupa bilangan bulat minimal 0.
- Validasi client-side menggunakan Pristine.js dan pembuatan slug otomatis menggunakan Slugify.
- Upload gambar produk melalui endpoint `file-uploads` dengan dukungan drag and drop, preview, dan hapus gambar.
- Validasi file gambar: JPG, JPEG, PNG, GIF, atau WEBP dengan ukuran maksimal 2 MB, disimpan pada disk `public`.
- Gambar yang diunggah ikut dihapus dari storage ketika produk dihapus.
- Notifikasi sukses setelah produk atau kategori berhasil dibuat, diperbarui, atau dihapus.
- Halaman detail produk admin dengan tombol untuk melihat produk di halaman shop dan mengedit produk.
- Status aktif menu navigasi mengikuti seluruh route `products.*` dan `product-categories.*`.
- Test fitur untuk pembuatan, validasi, penghapusan produk, halaman edit, dan upload file.

### Dibangun Menggunakan

- Laravel Resource Controller
- Eloquent ORM
- MySQL
- Laravel Blade
- Laravel Storage
- Tailwind CSS 4
- Pristine.js
- Slugify
- Vite
- Pest

### File Terkait

```text
app/Http/Controllers/ProductController.php
app/Http/Controllers/ProductCategoryController.php
app/Http/Controllers/FileUploadController.php
app/Http/Controllers/HomeController.php
resources/views/admin/products/index.blade.php
resources/views/admin/products/create.blade.php
resources/views/admin/products/edit.blade.php
resources/views/admin/products/detail.blade.php
resources/views/admin/products/_form.blade.php
resources/views/admin/products/_file_upload.blade.php
resources/views/admin/categories/index.blade.php
resources/views/admin/categories/_form.blade.php
resources/js/product.form.js
resources/js/category.form.js
resources/js/file_upload.form.js
vite.config.js
routes/web.php
tests/Feature/ProductTest.php
tests/Feature/FileUploadTest.php
```

## Tugas Sesi 18 : Dashboard Summary & Analytics

![Thumbnail](.thumbnails/tugas_sesi_18_dashboard.png)

### Deskripsi

Membuat tampilan dashboard utama yang menampilkan ringkasan informasi tentang jumlah produk, jumlah kategori produk, dan jumlah klik produk, dilengkapi grafik analitik serta tabel klik produk.

### Fitur

- `DashboardController@index` menghitung jumlah produk dan kategori langsung dari database menggunakan Eloquent.
- Kartu ringkasan menampilkan Total Products, Total Categories, Total Orders, dan Total Customers.
- Tabel `Products Clicks` menjadi ringkasan jumlah klik produk dan menampilkan 5 produk terbaru beserta jumlah klik bulan lalu, bulan ini, total klik, serta persentase tren.
- Data klik produk disimulasikan dari ID produk untuk kebutuhan tampilan dashboard.
- Grafik `Orders Analytic` berupa line chart berisi data income dan expense per bulan.
- Grafik `Operating System` berupa doughnut chart berisi distribusi sistem operasi.
- Data grafik dikirim dari controller dalam bentuk JSON dan dirender menggunakan Chart.js.
- Route dashboard dipindahkan ke controller dan tetap dilindungi middleware `auth` serta `verified`.
- Test fitur dashboard untuk memastikan ringkasan dan elemen grafik tampil.

### Dibangun Menggunakan

- Laravel Controller
- Eloquent ORM
- MySQL
- Laravel Blade
- Tailwind CSS 4
- Chart.js
- Lucide Icons
- Vite
- Pest

### File Terkait

```text
app/Http/Controllers/DashboardController.php
resources/views/dashboard.blade.php
resources/js/dashboard.js
vite.config.js
routes/web.php
tests/Feature/DashboardTest.php
```

## Tugas Sesi 19 : Role & Admin Middleware

![Thumbnail](.thumbnails/tugas_sesi_19_admin_dashboard.png)
![Thumbnail](.thumbnails/tugas_sesi_19_user_profile.png)

### Deskripsi

Menambahkan kolom role pada tabel users melalui migration, membuat middleware untuk membatasi akses hanya untuk admin, lalu menerapkan middleware tersebut pada route dashboard dan pengelolaan produk/kategori.

### Fitur

- Migration `add_role_to_users_table` menambahkan kolom `role` bertipe string dengan nilai default `user`.
- Model `User` menambahkan `role` ke atribut fillable.
- `AdminMiddleware` memeriksa pengguna yang sudah login dan memiliki role `admin`; pengguna lain diarahkan ke halaman home dengan pesan error.
- Alias middleware `admin` didaftarkan pada `bootstrap/app.php`.
- Route dashboard, produk, kategori, dan upload file dibatasi menggunakan middleware `admin`.
- Blade directive `@admin` ditambahkan untuk menampilkan menu Dashboard, Products, dan Product Categories hanya kepada admin.
- Menu admin juga disembunyikan pada tampilan navigasi responsif untuk pengguna non-admin.
- `UserFactory` mengisi role default `user`, sedangkan `DatabaseSeeder` membuat akun admin `admin@ecommerce.com` dengan password `password`.
- Data pengguna dummy menggunakan locale Indonesia (`id_ID`).

### Dibangun Menggunakan

- Laravel Migration
- Laravel Middleware
- Laravel Blade Directive
- Eloquent ORM
- Laravel Seeder & Factory
- MySQL

### File Terkait

```text
database/migrations/2026_10_26_132001_add_role_to_users_table.php
app/Http/Middleware/AdminMiddleware.php
bootstrap/app.php
app/Models/User.php
app/Providers/AppServiceProvider.php
database/factories/UserFactory.php
database/seeders/DatabaseSeeder.php
resources/views/layouts/navigation.blade.php
routes/web.php
```

## Tugas Sesi 20 : Complete Back-End Product System

### Deskripsi

Melengkapi proses back-end untuk menambahkan produk dan kategori produk. Form produk ditampilkan pada halaman tersendiri, sedangkan form kategori menggunakan dialog pada halaman daftar kategori. Data dikirim melalui route POST, divalidasi di controller, lalu disimpan ke database.

### Fitur

- `ProductController@create` menampilkan halaman form tambah produk beserta daftar kategori.
- Form tambah produk dikirim ke route bernama `products.store` dengan method POST.
- Form tambah kategori ditampilkan melalui dialog pada halaman daftar kategori dan dikirim ke route `product-categories.store` dengan method POST.
- `ProductController@store` memvalidasi nama, slug unik, deskripsi, gambar, harga, stok, dan kategori sebelum membuat data produk.
- `ProductCategoryController@store` memvalidasi nama dan slug sebelum membuat data kategori.
- Pesan sukses ditampilkan setelah produk atau kategori berhasil ditambahkan.
- Validasi sisi client pada form kategori menggunakan Pristine.js dan pembuatan slug otomatis menggunakan Slugify.

### Dibangun Menggunakan

- Laravel Controller dan Resource Routing
- Laravel Validation
- Eloquent ORM
- MySQL
- Laravel Blade
- Pristine.js
- Slugify

### File Terkait

```text
app/Http/Controllers/ProductController.php
app/Http/Controllers/ProductCategoryController.php
resources/views/admin/products/create.blade.php
resources/views/admin/products/_form.blade.php
resources/views/admin/categories/index.blade.php
resources/views/admin/categories/_form.blade.php
resources/js/category.form.js
routes/web.php
```

Catatan: form tambah kategori saat ini menggunakan dialog pada halaman daftar kategori. Method `ProductCategoryController@create` masih kosong dan belum digunakan oleh alur tersebut.

## Tugas Sesi 21 : Product Editing & Deletion System

### Deskripsi

Menambahkan fitur untuk mengubah dan menghapus data produk serta kategori produk melalui halaman admin. Produk dapat diedit pada halaman khusus dengan form yang menggunakan kembali komponen form produk, sedangkan kategori diedit melalui dialog pada halaman daftar kategori.

### Fitur

- Tombol Edit pada daftar produk membuka halaman edit melalui route `products.edit`.
- `ProductController@edit` mengambil data produk dan daftar kategori untuk mengisi form.
- Form edit menggunakan partial `admin.products._form` yang sama dengan form tambah, dengan method PUT menuju route `products.update`.
- `ProductController@update` memvalidasi input, termasuk keunikan slug dengan mengecualikan produk yang sedang diedit, kemudian memperbarui data produk.
- Form edit menampilkan gambar produk saat ini dan mendukung pengelolaan gambar melalui komponen upload.
- Tombol Delete mengirim request DELETE ke route `products.destroy`; controller menghapus data produk dan file gambar terkait dari storage publik.
- Kategori dapat diedit melalui dialog yang mengisi data kategori dan mengirim request PUT ke route `product-categories.update`.
- `ProductCategoryController@update` memvalidasi dan memperbarui data kategori.
- Produk dan kategori dapat dihapus melalui route DELETE masing-masing.
- Route resource produk dan kategori berada di bawah prefix `/dashboard` dan dilindungi middleware `admin`.

### Dibangun Menggunakan

- Laravel Resource Controller dan Resource Routing
- Laravel Validation
- Eloquent ORM
- Laravel Blade
- Laravel Storage
- JavaScript
- MySQL

### File Terkait

```text
app/Http/Controllers/ProductController.php
app/Http/Controllers/ProductCategoryController.php
resources/views/admin/products/index.blade.php
resources/views/admin/products/edit.blade.php
resources/views/admin/products/_form.blade.php
resources/views/admin/categories/index.blade.php
resources/views/admin/categories/_form.blade.php
resources/js/category.form.js
routes/web.php
tests/Feature/ProductTest.php
```

Catatan: validasi slug pada `ProductCategoryController@update` saat ini masih menerapkan aturan unik tanpa mengecualikan kategori yang sedang diedit. Akibatnya, penyimpanan edit kategori dengan slug yang tidak berubah dapat ditolak oleh validasi.

## Tugas Sesi 22 : Final Dashboard Adjustments with AI

### Deskripsi

Melakukan penyesuaian akhir pada pengelolaan produk dan kategori melalui controller serta melengkapi dashboard admin. Fitur edit dan hapus produk/kategori diintegrasikan dengan route resource, sementara dashboard menampilkan ringkasan data, visualisasi analitik, dan daftar produk berdasarkan jumlah klik.

### Fitur

- Menyempurnakan alur `ProductController` untuk menampilkan daftar produk, form edit, memperbarui data, dan menghapus produk berdasarkan ID melalui route resource.
- Menampilkan form edit produk dengan data produk saat ini dan pilihan kategori.
- Memvalidasi perubahan data produk, termasuk validasi slug unik yang mengecualikan produk yang sedang diedit.
- Menyediakan pengelolaan kategori melalui `ProductCategoryController`, termasuk edit melalui dialog dan penghapusan berdasarkan ID.
- Menampilkan ringkasan jumlah produk, kategori, dan pesanan pada dashboard admin.
- Menampilkan grafik analitik pesanan yang membandingkan data income dan expense per bulan.
- Menampilkan visualisasi distribusi operating system.
- Menampilkan daftar produk dengan informasi klik bulan sebelumnya, klik bulan berjalan, total klik, dan tren perubahan.
- Menggunakan middleware `admin` untuk melindungi dashboard dan route pengelolaan produk serta kategori.

### Dibangun Menggunakan

- Laravel Controller dan Resource Routing
- Laravel Validation dan Eloquent ORM
- Laravel Blade
- MySQL
- JavaScript dan Chart.js
- Laravel Middleware

### File Terkait

```text
app/Http/Controllers/ProductController.php
app/Http/Controllers/ProductCategoryController.php
app/Http/Controllers/DashboardController.php
routes/web.php
resources/views/dashboard.blade.php
resources/views/admin/products/
resources/views/admin/categories/
resources/js/dashboard.js
resources/js/category.form.js
```

### Catatan Implementasi

- Jumlah produk, kategori, dan pesanan pada kartu statistik diambil dari database. Jumlah pelanggan masih menggunakan nilai statis.
- Data grafik income/expense dan distribusi operating system masih berupa data simulasi.
- Data klik dan tren produk pada dashboard juga dihitung menggunakan nilai simulasi, bukan catatan aktivitas pengunjung aktual.
- Validasi slug pada `ProductCategoryController@update` masih perlu disesuaikan agar kategori dapat disimpan ketika slug tidak berubah.

## Tugas Sesi 23 : Streamlined Back-End Finalization Using AI

### Deskripsi

Menyelesaikan integrasi dashboard admin dengan data aktual dari database. Menambahkan pencatatan jumlah kunjungan pada setiap halaman detail produk, menghitung total produk, total klik, kategori, dan pesanan, serta menyajikan statistik jumlah pesanan per bulan dan jumlah pesanan berdasarkan status.

### Fitur

- Menambahkan kolom `click` bertipe unsigned big integer dengan nilai awal `0` pada tabel `products` melalui migration baru.
- Menambahkan atribut `click` ke daftar fillable pada model `Product`.
- Menambah jumlah klik produk secara otomatis setiap kali halaman detail produk dibuka melalui `HomeController@productDetail`.
- Menampilkan empat metrik dashboard dari database: total produk, total klik produk, total kategori, dan total pesanan.
- Mengurutkan lima produk dengan jumlah klik tertinggi berdasarkan nilai `products.click`.
- Mengganti grafik income/expense simulasi menjadi grafik jumlah pesanan per bulan pada tahun berjalan berdasarkan tabel `orders`.
- Mengganti visualisasi Operating System menjadi Order Status yang menghitung jumlah pesanan berdasarkan nilai `orders.status`.
- Menampilkan status umum seperti Pending, Processing, Success, Failed, Refund, dan Cancelled, termasuk status tambahan yang ditemukan pada database.
- Memastikan seluruh angka dashboard berasal dari agregasi database, bukan angka analitik buatan.

### Dibangun Menggunakan

- Laravel Migration
- Laravel Controller
- Eloquent ORM dan Query Builder
- MySQL
- Laravel Blade
- JavaScript
- Chart.js
- Pest Feature Tests

### File Terkait

```text
database/migrations/2026_11_04_000001_add_click_to_products_table.php
app/Models/Product.php
app/Http/Controllers/HomeController.php
app/Http/Controllers/DashboardController.php
resources/views/dashboard.blade.php
resources/js/dashboard.js
tests/Feature/ProductTest.php
tests/Feature/DashboardTest.php
```

### Catatan Implementasi

- Nilai klik dihitung satu kali per produk untuk setiap session browser. Refresh halaman atau membuka kembali produk yang sama selama session masih aktif tidak menambah hitungan; produk lain tetap memiliki penghitung session tersendiri. Session baru dapat dihitung sebagai kunjungan baru.
- Grafik bulanan menampilkan jumlah order yang dibuat pada masing-masing bulan di tahun berjalan.
- Status pesanan dihitung secara dinamis dari kolom `orders.status`. Status umum tetap ditampilkan dengan nilai `0` jika belum memiliki pesanan.
- Skema tabel `orders` belum memiliki kolom biaya/pengeluaran, sehingga grafik income/expense tidak lagi ditampilkan dan diganti dengan jumlah pesanan aktual.
- Migration penambahan kolom klik sudah dijalankan pada database MySQL yang dikonfigurasi di project.

## Cara Menjalankan

Pastikan PHP 8.3+, Composer, Node.js, npm, dan MySQL sudah terpasang. Sejak tugas sesi 14, proyek menggunakan database MySQL.

Buat database MySQL terlebih dahulu:

```bash
mysql -u root -p -e "CREATE DATABASE ecommerce10;"
```

```bash
composer install
cp .env.example .env
php artisan key:generate
```

Pastikan konfigurasi database pada file `.env` menggunakan MySQL:

```dotenv
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ecommerce10
DB_USERNAME=root
DB_PASSWORD=
```

Setelah konfigurasi database benar, jalankan migration, storage link untuk upload gambar, dan frontend:

```bash
php artisan migrate --seed
php artisan storage:link
npm install
npm run dev
```

Jalankan server Laravel pada terminal terpisah:

```bash
php artisan serve
```

Kemudian buka `http://127.0.0.1:8000` di browser. Halaman login tersedia di `/login`, registrasi di `/register`, dan dashboard pengguna di `/dashboard`.

Untuk menjalankan ulang seeder:

```bash
php artisan db:seed
```

## Struktur Proyek

```text
ecommerce10/
├── app/
│   ├── Http/Controllers/       # Controller dashboard, halaman, produk, kategori, upload, cart, order, auth, dan profil
│   ├── Http/Middleware/        # Middleware pembatasan akses admin
│   ├── Http/Requests/          # Form request validasi auth dan profil
│   ├── Models/                 # Model Eloquent beserta relasinya
│   └── View/Components/        # Class komponen Blade (termasuk layout Breeze)
├── database/
│   ├── migrations/             # Struktur tabel database
│   └── seeders/                # Data dummy produk dan kategori
├── resources/
│   ├── css/app.css             # Style Tailwind CSS
│   ├── js/                     # Entry point, script dashboard, form produk/kategori, dan upload
│   └── views/
│       ├── dashboard.blade.php # Dashboard utama dengan ringkasan dan grafik
│       ├── components/         # Navbar, footer, layout, product card, dll.
│       ├── home/               # Halaman utama dan daftar produk (dengan filter & pagination)
│       ├── product/            # Halaman detail produk
│       ├── cart/               # Halaman keranjang
│       ├── admin/              # Halaman admin daftar, tambah, edit, dan detail produk/kategori
│       ├── auth/               # Halaman login, registrasi, dan reset password
│       ├── layouts/            # Layout aplikasi dan guest dari Breeze
│       ├── profile/            # Halaman pengelolaan profil
│       └── vendor/pagination/  # Template pagination Tailwind
├── routes/web.php              # Definisi route utama
├── routes/auth.php             # Definisi route autentikasi
├── composer.json               # Dependency PHP
├── package.json                # Dependency frontend
├── vite.config.js              # Konfigurasi Vite
└── README.md
```
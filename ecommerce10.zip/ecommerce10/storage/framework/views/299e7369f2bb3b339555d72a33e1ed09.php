<!DOCTYPE html>
<html lang="<?php echo e(str_replace("_", "-", app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title ?? 'My Ecommerce'); ?></title>
    <meta name="author" content="<?php echo e($author ?? 'My Ecommerce'); ?>">
    <meta name="keywords" content="<?php echo e($keywords ?? 'e-commerce, online shopping, store'); ?>">
    <meta name="description" content="<?php echo e($description ?? 'My Ecommerce Site'); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <?php echo $__env->yieldPushContent('head'); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body data-boost="true">
    <?php echo $__env->make('components.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="mx-auto min-h-[calc(100vh-5rem)] w-full max-w-7xl px-4 py-5 sm:px-6 sm:py-8 lg:px-8">
        <?php echo e($slot); ?>

    </main>
    <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/components/layout-component.blade.php ENDPATH**/ ?>
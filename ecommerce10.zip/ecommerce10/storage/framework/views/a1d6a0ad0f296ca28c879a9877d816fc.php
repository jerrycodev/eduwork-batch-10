<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">Detail Order #<?php echo e($order->id); ?></h2>
            <a href="<?php echo e(route('orders.index')); ?>" class="text-sm text-indigo-600 underline">&larr; Kembali ke Orders</a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6 sm:py-8 lg:py-10">
        <div class="mx-auto grid w-full max-w-7xl grid-cols-1 items-start gap-6 px-4 sm:px-6 lg:px-8 lg:grid-cols-3">
            <section class="overflow-hidden bg-white shadow-sm sm:rounded-lg lg:col-span-2">
                <div class="border-b px-6 py-4">
                    <h3 class="font-semibold text-gray-800">Order Items</h3>
                </div>
                <div class="w-full overflow-x-auto">
                    <table class="table min-w-[560px]">
                        <thead>
                            <tr class="table-row">
                                <th class="table-cell">Product</th>
                                <th class="table-cell">Price</th>
                                <th class="table-cell">Quantity</th>
                                <th class="table-cell">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr class="table-row">
                                    <td class="table-cell"><?php echo e($item->product_name); ?></td>
                                    <td class="table-cell">Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                                    <td class="table-cell"><?php echo e($item->quantity); ?></td>
                                    <td class="table-cell">Rp <?php echo e(number_format($item->total, 0, ',', '.')); ?></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                <tr class="table-row"><td class="table-cell text-center" colspan="4">Tidak ada item pesanan.</td></tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="table-row">
                                <th class="table-cell text-right" colspan="3">Total</th>
                                <th class="table-cell">Rp <?php echo e(number_format($order->total, 0, ',', '.')); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </section>

            <aside class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="border-b px-6 py-4"><h3 class="font-semibold text-gray-800">Customer Information</h3></div>
                <dl class="space-y-4 px-6 py-5 text-sm">
                    <div><dt class="text-gray-500">Customer</dt><dd class="mt-1 font-medium text-gray-900"><?php echo e($order->user_name); ?></dd></div>
                    <div><dt class="text-gray-500">Email</dt><dd class="mt-1 break-all font-medium text-gray-900"><?php echo e($order->user_email); ?></dd></div>
                    <div><dt class="text-gray-500">Phone</dt><dd class="mt-1 font-medium text-gray-900"><?php echo e($order->user_phone ?: 'Belum diisi'); ?></dd></div>
                    <div><dt class="text-gray-500">Shipping Address</dt><dd class="mt-1 font-medium text-gray-900"><?php echo e(collect([$order->address, $order->city, $order->state, $order->zip, $order->country])->filter()->join(', ') ?: 'Belum diisi'); ?></dd></div>
                    <div><dt class="text-gray-500">Order Date</dt><dd class="mt-1 font-medium text-gray-900"><?php echo e($order->created_at->format('d M Y, H:i')); ?></dd></div>
                    <div><dt class="text-gray-500">Status</dt><dd class="mt-1 font-medium text-gray-900"><?php echo e(ucfirst($order->status)); ?></dd></div>
                </dl>
            </aside>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/admin/orders/show.blade.php ENDPATH**/ ?>
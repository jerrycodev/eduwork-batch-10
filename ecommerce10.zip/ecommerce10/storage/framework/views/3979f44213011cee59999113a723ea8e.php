<div class="alert <?php echo e($class ?? ''); ?>" role="alert" data-variant="<?php echo e($type ?? ''); ?>">
    <i class="alert-icon" data-lucide=<?php echo e($icon ?? 'info'); ?>></i>
    <div class="alert-content">
        <?php echo e($slot); ?>

    </div>
    
    <button type="button" class="alert-dismiss" data-action="alert#dismiss" onclick="this.parentElement.remove()">
        <i data-lucide="x" class="h-4 w-4"></i>
    </button>
</div>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/components/alert.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginalb03144a863f57b66026dd23cf270e65d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb03144a863f57b66026dd23cf270e65d = $attributes; } ?>
<?php $component = App\View\Components\LayoutComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LayoutComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
            <a href="<?php echo e(route('orders.customer.index')); ?>" class="text-sm text-muted-foreground hover:text-foreground">&larr; Kembali ke pesanan</a>
            <h1 class="mt-2 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">Pesanan #<?php echo e($order->id); ?></h1>
            <p class="mt-1 text-sm text-muted-foreground">Dibuat <?php echo e($order->created_at->format('d M Y, H:i')); ?></p>
        </div>
        <span class="badge" data-variant="secondary"><?php echo e(ucfirst($order->status)); ?></span>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="mb-5 rounded-lg border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm text-green-700" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="grid grid-cols-1 items-start gap-6 lg:grid-cols-12">
        <section class="card min-w-0 lg:col-span-8">
            <div class="card-header border-b border-gray-200"><h2 class="card-title">Item Pesanan</h2></div>
            <div class="card-content p-0 divide-y divide-border divide-gray-200">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="flex items-start justify-between gap-4 p-4">
                        <div class="min-w-0">
                            <p class="font-semibold text-foreground"><?php echo e($item->product_name); ?></p>
                            <p class="mt-1 text-sm text-muted-foreground"><?php echo e($item->quantity); ?> × Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></p>
                        </div>
                        <p class="shrink-0 font-semibold text-foreground">Rp <?php echo e(number_format($item->total, 0, ',', '.')); ?></p>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
            <div class="card-footer border-t border-gray-200 flex items-center justify-between gap-4">
                <span class="font-semibold text-foreground">Total Pesanan</span>
                <span class="text-lg font-bold text-foreground">Rp <?php echo e(number_format($order->total, 0, ',', '.')); ?></span>
            </div>
        </section>

        <aside class="card min-w-0 lg:col-span-4">
            <div class="card-header border-b border-gray-200"><h2 class="card-title">Informasi Pemesan</h2></div>
            <div class="card-content space-y-3 py-5 text-sm">
                <div><p class="text-muted-foreground">Nama</p><p class="font-medium text-foreground"><?php echo e($order->user_name); ?></p></div>
                <div><p class="text-muted-foreground">Email</p><p class="break-all font-medium text-foreground"><?php echo e($order->user_email); ?></p></div>
                <div><p class="text-muted-foreground">Telepon</p><p class="font-medium text-foreground"><?php echo e($order->user_phone ?: 'Belum diisi'); ?></p></div>
                <div><p class="text-muted-foreground">Alamat pengiriman</p><p class="font-medium text-foreground"><?php echo e(collect([$order->address, $order->city, $order->state, $order->zip, $order->country])->filter()->join(', ') ?: 'Belum diisi'); ?></p></div>
            </div>
        </aside>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb03144a863f57b66026dd23cf270e65d)): ?>
<?php $attributes = $__attributesOriginalb03144a863f57b66026dd23cf270e65d; ?>
<?php unset($__attributesOriginalb03144a863f57b66026dd23cf270e65d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb03144a863f57b66026dd23cf270e65d)): ?>
<?php $component = $__componentOriginalb03144a863f57b66026dd23cf270e65d; ?>
<?php unset($__componentOriginalb03144a863f57b66026dd23cf270e65d); ?>
<?php endif; ?>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/orders/show.blade.php ENDPATH**/ ?>
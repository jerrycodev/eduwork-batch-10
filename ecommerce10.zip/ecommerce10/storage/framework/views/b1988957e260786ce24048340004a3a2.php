<?php if (isset($component)) { $__componentOriginalb03144a863f57b66026dd23cf270e65d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb03144a863f57b66026dd23cf270e65d = $attributes; } ?>
<?php $component = App\View\Components\LayoutComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LayoutComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="mb-6 flex flex-wrap items-center justify-between gap-3 sm:mb-8">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">Pesanan Saya</h1>
            <p class="mt-1 text-sm text-muted-foreground">Riwayat pesanan yang sudah tercatat.</p>
        </div>
        <a href="<?php echo e(route('shop')); ?>" class="btn" data-variant="outline">Lanjut Belanja</a>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="mb-5 rounded-lg border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm text-green-700" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($orders->isEmpty()): ?>
        <div class="card flex flex-col items-center px-5 py-12 text-center">
            <i data-lucide="package-search" class="mb-4 h-10 w-10 text-muted-foreground"></i>
            <h2 class="font-semibold text-foreground">Belum ada pesanan</h2>
            <p class="mt-2 text-sm text-muted-foreground">Pesanan yang dibuat akan muncul di halaman ini.</p>
            <a href="<?php echo e(route('shop')); ?>" class="btn mt-5" data-variant="default">Mulai Belanja</a>
        </div>
    <?php else: ?>
        <div class="overflow-hidden rounded-xl border border-gray-200 bg-card">
            <div class="overflow-x-auto">
                <table class="w-full min-w-[640px] text-left text-sm">
                    <thead class="bg-muted/50 text-muted-foreground">
                        <tr>
                            <th class="px-4 py-3 font-medium">No. Pesanan</th>
                            <th class="px-4 py-3 font-medium">Tanggal</th>
                            <th class="px-4 py-3 font-medium">Item</th>
                            <th class="px-4 py-3 font-medium">Total</th>
                            <th class="px-4 py-3 font-medium">Status</th>
                            <th class="px-4 py-3 text-right font-medium">Detail</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-border divide-gray-200">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td class="px-4 py-3 font-semibold text-foreground">#<?php echo e($order->id); ?></td>
                                <td class="px-4 py-3 text-muted-foreground"><?php echo e($order->created_at->format('d M Y, H:i')); ?></td>
                                <td class="px-4 py-3 text-foreground"><?php echo e($order->order_items_count); ?></td>
                                <td class="px-4 py-3 font-semibold text-foreground">Rp <?php echo e(number_format($order->total, 0, ',', '.')); ?></td>
                                <td class="px-4 py-3"><span class="badge" data-variant="secondary"><?php echo e(ucfirst($order->status)); ?></span></td>
                                <td class="px-4 py-3 text-right"><a href="<?php echo e(route('orders.customer.show', $order)); ?>" class="font-medium text-primary hover:underline">Lihat</a></td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="mt-5"><?php echo e($orders->links()); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb03144a863f57b66026dd23cf270e65d)): ?>
<?php $attributes = $__attributesOriginalb03144a863f57b66026dd23cf270e65d; ?>
<?php unset($__attributesOriginalb03144a863f57b66026dd23cf270e65d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb03144a863f57b66026dd23cf270e65d)): ?>
<?php $component = $__componentOriginalb03144a863f57b66026dd23cf270e65d; ?>
<?php unset($__componentOriginalb03144a863f57b66026dd23cf270e65d); ?>
<?php endif; ?>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/orders/index.blade.php ENDPATH**/ ?>
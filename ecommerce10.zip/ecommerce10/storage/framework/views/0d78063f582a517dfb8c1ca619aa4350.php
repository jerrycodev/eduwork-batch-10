
<?php
$columns = [
    ['label'=>'Name', 'value'=>$product->name],
    ['label'=>'Slug', 'value'=>$product->slug],
    ['label'=>'Category', 'value'=>$product->category->name],
    ['label'=>'Price', 'value'=> "Rp ".number_format($product->price, 0, ',', '.')],
    ['label'=>'Stock', 'value'=>$product->stock],
    ['label'=>'Description', 'value'=>$product->description],
    ['label'=>'Image', 'value'=>$product->image],
];
?>


<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                <?php echo e(__('Product Detail')); ?>

            </h2>
            <a href="<?php echo e(route('products.index')); ?>" class="btn" data-variant="secondary">
                <i data-lucide="arrow-left" class="h-4 w-4"></i>
                <?php echo e(__('Go to Products')); ?>

            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6 sm:py-8 lg:py-10">
        <div class="mx-auto flex max-w-7xl flex-col gap-4 px-4 sm:px-6 lg:px-8">

            <div class="bg-white shadow sm:rounded-lg flex flex-col divide-y divide-neutral-200">

                <div class="flex flex-wrap items-center gap-4 p-4">
                    
                    <a href="<?php echo e(route('product-detail', $product)); ?>" target="_blank" class="btn bg-indigo-400">
                        <i data-lucide="eye" class="h-4 w-4"></i>
                        View Product on the Shop
                    </a>
                    
                    <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn bg-indigo-400">
                        <i data-lucide="pencil" class="h-4 w-4"></i>
                        Edit Product
                    </a>
                </div>

                <div class="w-full overflow-x-auto"><table class="table min-w-[560px]">
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr class="table-row">
                                <td class="table-cell"><?php echo e($column['label']); ?></td>
                                <td class="table-cell">:</td>
                                <td class="table-cell w-full">
                                     <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($column['label'] === 'Image'): ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($column['value']): ?>
                                            <img src="<?php echo e(asset($column['value'])); ?>" alt="<?php echo e($product->name); ?>" class="h-36 w-36 rounded-lg object-cover shadow sm:h-48 sm:w-48">
                                        <?php else: ?>
                                            <span class="text-gray-400">No Image</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php else: ?>
                                        <?php echo e($column['value']); ?>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table></div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/admin/products/detail.blade.php ENDPATH**/ ?>
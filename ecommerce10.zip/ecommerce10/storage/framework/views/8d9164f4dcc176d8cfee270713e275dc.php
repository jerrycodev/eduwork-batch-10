<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto flex max-w-7xl flex-col gap-4 px-4 sm:px-6 lg:px-8">
            
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $metrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="card">
                        <div class="card-header flex flex-row items-center justify-between pb-2">
                            <p class="card-description text-[0.8125rem] font-medium text-[--foreground]">
                                <?php echo e($metric['label']); ?>

                            </p>
                            <i data-lucide="<?php echo e($metric['icon']); ?>" class="h-5 w-5"></i>
                        </div>

                        <div class="card-content pt-1">
                            <p class="m-0 text-[1.625rem] font-bold tracking-tight">
                                <?php echo e($metric['value']); ?>

                            </p>

                        </div>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>


            
            <div class="grid grid-cols-1 gap-4 lg:grid-cols-5">
                
                <div class="card lg:col-span-3">
                    <div class="card-header flex flex-row items-start justify-between gap-4">
                        <div class="flex flex-col gap-2">
                            <h3 class="card-title text-lg">Orders This Year</h3>
                            <p class="card-description text-xs">Monthly order volume from database</p>
                        </div>

                    </div>
                    <div class="card-content pt-4">
                        <div class="h-70">
                            <canvas id="orders-chart" role="img"
                                aria-label="Monthly order totals from database"></canvas>
                        </div>
                    </div>
                </div>

                
                <div class="card lg:col-span-2">
                    <div class="card-header flex flex-row items-center justify-between gap-3">
                        <div>
                            <h3 class="card-title text-lg">Order Status</h3>
                            <p class="card-description text-xs">Order totals grouped by current status</p>
                        </div>
                    </div>
                    <div class="card-content pt-4">
                        <div class="grid grid-cols-1 items-center gap-4 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
                            <ul class="flex flex-col gap-3">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $order_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <li class="flex items-center justify-between gap-2 text-sm text-[--foreground]">
                                        <span class="flex items-center gap-2">
                                            <span class="h-2.5 w-2.5 shrink-0 rounded-full"
                                                style="background-color:<?php echo e($orderStatus['color']); ?>"></span>
                                            <?php echo e($orderStatus['name']); ?>

                                        </span>
                                        <span class="font-semibold tabular-nums"><?php echo e(number_format($orderStatus['value'], 0, ',', '.')); ?></span>
                                    </li>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </ul>
                            <div class="h-55 max-w-55 mx-auto w-full">
                                <canvas id="order-status-chart" role="img"
                                    aria-label="Order totals grouped by status"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="card divide-y divide-neutral-200">
                <div class="card-header flex flex-row flex-wrap items-center justify-between gap-3 pb-4">
                    <div>
                        <h3 class="card-title text-lg">Products Clicks</h3>
                        <p class="card-description">Products ranked by total detail-page views.</p>
                    </div>
                    <span class="badge" data-variant="outline">All time</span>
                </div>
                <div class="card-content p-0">
                    <div class="w-full overflow-x-auto"><table class="table min-w-[520px]">
                        <thead>
                            <tr class="table-row">
                                <th class="table-head w-16 rounded-none">Image</th>
                                <th class="table-head w-full rounded-none">Product</th>
                                <th class="table-head rounded-none text-right">Total Clicks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $products_clicks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr class="table-row">
                                    <td class="table-cell">
                                        <img src="<?php echo e($product['image']); ?>" alt="<?php echo e($product['label']); ?>"
                                            class="h-11 w-11 rounded-xl object-cover ring-1 ring-[--border]">
                                    </td>
                                    <td class="table-cell">
                                        <a href="<?php echo e($product['url']); ?>" class="font-medium hover:underline">
                                            <?php echo e($product['label']); ?>

                                        </a>
                                    </td>
                                    <td class="table-cell text-right font-semibold tabular-nums">
                                        <?php echo e(number_format($product['clicks'], 0, ',', '.')); ?>

                                    </td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                <tr>
                                    <td colspan="3" class="table-cell py-8 text-center text-[--muted-foreground]">
                                        No products available yet.
                                    </td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table></div>
                </div>
            </div>
        </div>
    </div>

    <script type="application/json" id="dashboard-chart-data"><?php echo json_encode($chart_data, 15, 512) ?></script>
    <?php $__env->startPush('scripts'); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/dashboard.js'); ?>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/dashboard.blade.php ENDPATH**/ ?>
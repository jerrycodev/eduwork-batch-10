<?php if (isset($component)) { $__componentOriginalb03144a863f57b66026dd23cf270e65d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb03144a863f57b66026dd23cf270e65d = $attributes; } ?>
<?php $component = App\View\Components\LayoutComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LayoutComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="mb-6 flex flex-wrap items-center justify-between gap-3 sm:mb-8">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">Keranjang Belanja</h1>
            <p class="mt-1 text-sm text-muted-foreground">Periksa kembali produk sebelum melanjutkan pesanan.</p>
        </div>
        <span class="badge" data-variant="secondary">
            <?php echo e($totalQuantity); ?> Barang
        </span>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="mb-5 rounded-lg border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm text-green-700" role="status">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="mb-5 rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cartItems->isEmpty()): ?>
        <div class="card flex flex-col items-center px-5 py-12 text-center sm:py-16">
            <div class="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-muted">
                <i data-lucide="shopping-cart" class="h-9 w-9 text-muted-foreground"></i>
            </div>
            <h2 class="text-lg font-semibold text-foreground">Keranjang belanja masih kosong</h2>
            <p class="mt-2 max-w-md text-sm text-muted-foreground">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                    Yuk, temukan produk yang kamu butuhkan dan tambahkan ke keranjang.
                <?php else: ?>
                    Masuk ke akunmu untuk melihat keranjang, atau mulai jelajahi produk yang tersedia.
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </p>
            <a href="<?php echo e(route('shop')); ?>" class="btn mt-6" data-variant="default">
                Mulai Belanja
                <i data-lucide="arrow-right" class="ml-2 h-4 w-4"></i>
            </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="mt-3 text-sm font-medium text-primary hover:underline">Masuk ke akun</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 items-start gap-6 lg:grid-cols-12 lg:gap-8">
            <section class="flex min-w-0 flex-col gap-4 lg:col-span-8" aria-label="Daftar produk di keranjang">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php
                        $product = $item->product;
                        $image = $product->image;
                        $imageUrl = $image
                            ? (\Illuminate\Support\Str::startsWith($image, ['http://', 'https://', '/'])
                                ? $image
                                : asset('storage/' . $image))
                            : 'https://placehold.co/240x240?text=Produk';
                    ?>

                    <article class="card flex min-w-0 flex-col gap-4 p-4 sm:flex-row sm:items-center sm:gap-5 sm:p-5">
                        <a href="<?php echo e(route('product-detail', $product)); ?>"
                            class="h-24 w-24 shrink-0 self-start overflow-hidden rounded-lg bg-muted/50 sm:h-28 sm:w-28">
                            <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($product->name); ?>"
                                class="h-full w-full object-cover" loading="lazy">
                        </a>

                        <div class="flex min-w-0 flex-1 flex-col justify-between gap-3">
                            <div class="min-w-0">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->category): ?>
                                    <p class="mb-1 text-xs text-muted-foreground"><?php echo e($product->category->name); ?></p>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <a href="<?php echo e(route('product-detail', $product)); ?>"
                                    class="line-clamp-2 font-semibold text-foreground hover:text-primary">
                                    <?php echo e($product->name); ?>

                                </a>
                                <p class="mt-1 text-sm text-muted-foreground">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->stock > 0): ?>
                                        Stok tersedia: <?php echo e($product->stock); ?>

                                    <?php else: ?>
                                        <span class="text-destructive">Stok habis</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </p>
                            </div>
                            <p class="font-semibold text-foreground">
                                Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                                <span class="font-normal text-muted-foreground">/ item</span>
                            </p>
                        </div>

                        <div class="flex w-full items-end justify-between gap-4 border-t pt-4 sm:w-auto sm:min-w-36 sm:flex-col sm:items-end sm:border-0 sm:pt-0">
                            <form action="<?php echo e(route('cart.update', $item)); ?>" method="POST" class="flex items-center gap-2">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <label for="quantity-<?php echo e($item->id); ?>" class="sr-only">Jumlah <?php echo e($product->name); ?></label>
                                <input id="quantity-<?php echo e($item->id); ?>" name="quantity" type="number"
                                    value="<?php echo e($item->quantity); ?>" min="1" max="<?php echo e($product->stock); ?>"
                                    required class="input h-9 w-20 px-2 text-center" aria-label="Jumlah produk">
                                <button type="submit" class="btn h-9 px-3" data-variant="outline">
                                    Perbarui
                                </button>
                            </form>

                            <div class="flex items-center gap-3 sm:justify-end">
                                <p class="text-sm font-semibold text-foreground">
                                    Rp <?php echo e(number_format($product->price * $item->quantity, 0, ',', '.')); ?>

                                </p>
                                <form action="<?php echo e(route('cart.destroy', $item)); ?>" method="POST"
                                    onsubmit="return confirm('Hapus <?php echo e(addslashes($product->name)); ?> dari keranjang?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn h-9 w-9 text-destructive hover:bg-destructive/10"
                                        data-variant="ghost" data-size="icon" aria-label="Hapus <?php echo e($product->name); ?>">
                                        <i data-lucide="trash-2" class="h-4 w-4"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </article>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </section>

            <aside class="min-w-0 lg:col-span-4">
                <div class="card lg:sticky lg:top-24">
                    <div class="card-header border-b">
                        <h2 class="card-title text-lg">Ringkasan Belanja</h2>
                    </div>
                    <div class="card-content flex flex-col gap-4 py-5 sm:py-6">
                        <div class="flex justify-between gap-3 text-sm">
                            <span class="text-muted-foreground">Total barang</span>
                            <span class="font-medium text-foreground"><?php echo e($totalQuantity); ?> item</span>
                        </div>
                        <div class="flex justify-between gap-3 text-sm">
                            <span class="text-muted-foreground">Subtotal</span>
                            <span class="font-medium text-foreground">Rp <?php echo e(number_format($totalPrice, 0, ',', '.')); ?></span>
                        </div>
                        <hr class="my-1 border-muted">
                        <div class="flex items-center justify-between gap-3">
                            <span class="font-bold text-foreground">Total Harga</span>
                            <span class="text-lg font-bold text-foreground">Rp <?php echo e(number_format($totalPrice, 0, ',', '.')); ?></span>
                        </div>
                        <p class="text-xs text-muted-foreground">Ongkos kirim dan biaya lainnya akan dihitung pada tahap berikutnya.</p>
                    </div>
                    <div class="card-footer flex flex-col gap-3 pt-0">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                            <form action="<?php echo e(route('checkout.store')); ?>" method="POST" class="w-full">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn w-full" data-variant="default">
                                    Checkout Sekarang
                                    <i data-lucide="arrow-right" class="ml-2 h-4 w-4"></i>
                                </button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('login', ['redirect_to' => route('cart', absolute: false)])); ?>" class="btn w-full" data-variant="default">
                                Masuk untuk Checkout
                                <i data-lucide="arrow-right" class="ml-2 h-4 w-4"></i>
                            </a>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <a href="<?php echo e(route('shop')); ?>" class="btn w-full" data-variant="outline">
                            Lanjut Belanja
                        </a>
                    </div>
                </div>
            </aside>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb03144a863f57b66026dd23cf270e65d)): ?>
<?php $attributes = $__attributesOriginalb03144a863f57b66026dd23cf270e65d; ?>
<?php unset($__attributesOriginalb03144a863f57b66026dd23cf270e65d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb03144a863f57b66026dd23cf270e65d)): ?>
<?php $component = $__componentOriginalb03144a863f57b66026dd23cf270e65d; ?>
<?php unset($__componentOriginalb03144a863f57b66026dd23cf270e65d); ?>
<?php endif; ?>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/cart/index.blade.php ENDPATH**/ ?>
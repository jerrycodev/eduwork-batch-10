
<?php
$fields = [
    ['label' => 'Name', 'name' => 'name', 'value' => old('name', $product?->name), 'type' => 'text', 'colSpan' => 6],
    ['label' => 'Slug', 'name' => 'slug', 'value' => old('slug', $product?->slug), 'type' => 'text', 'colSpan' => 6],
    ['label' => 'Description', 'name' => 'description', 'value' => old('description', $product?->description), 'type' => 'textarea', 'colSpan' => 12],
    ['label' => 'Category', 'name' => 'category_id', 'value' => old('category_id', $product?->category_id), 'type' => 'select', 'options' => $categories, 'colSpan' => 4],
    ['label' => 'Price', 'name' => 'price', 'value' => old('price', $product?->price), 'type' => 'number', 'colSpan' => 4],
    ['label' => 'Stock', 'name' => 'stock', 'value' => old('stock', $product?->stock), 'type' => 'number', 'colSpan' => 4],
    ['label' => 'Image', 'name' => 'image', 'value' => old('image', $product?->image), 'type' => 'file', 'colSpan' => 12],
];
?>


<form id="product-form" action="<?php echo e($action); ?>" method="POST" class="form" autocomplete="off">

    <?php echo csrf_field(); ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-12 lg:gap-5">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="form-field min-w-0 col-span-1 <?php if($field['colSpan'] === 12): ?> sm:col-span-2 lg:col-span-12 <?php elseif($field['colSpan'] === 6): ?> lg:col-span-6 <?php elseif($field['colSpan'] === 4): ?> lg:col-span-4 <?php endif; ?>">
                <label class="label" for="<?php echo e($field['name']); ?>"><?php echo e($field['label']); ?></label>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($field['type'] === 'text' || $field['type'] === 'number'): ?>
                    <input class="input" id="<?php echo e($field['name']); ?>" name="<?php echo e($field['name']); ?>"
                        type="<?php echo e($field['type']); ?>" value="<?php echo e($field['value']); ?>" required
                        <?php if($field['type'] === 'number'): ?> min="0" step="1" <?php endif; ?>>
                <?php elseif($field['type'] === 'textarea'): ?>
                    <textarea class="textarea" id="<?php echo e($field['name']); ?>" name="<?php echo e($field['name']); ?>" required><?php echo e($field['value']); ?></textarea>
                <?php elseif($field['type'] === 'select'): ?>
                    <select class="select" id="<?php echo e($field['name']); ?>" name="<?php echo e($field['name']); ?>" required>
                        <option value="" disabled <?php if(! $field['value']): echo 'selected'; endif; ?>>-- Select --</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($option->id); ?>" <?php if((string) $field['value'] === (string) $option->id): echo 'selected'; endif; ?>>
                                <?php echo e($option->name); ?>

                            </option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                <?php elseif($field['type'] === 'file'): ?>
                    <?php echo $__env->make('admin.products._file_upload', ['image' => $field['value']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = [$field['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>
    <div class="form-actions mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
        <button class="btn bg-indigo-400" type="submit"
            data-variant="default"><?php echo e($submitLabel ?? 'Save changes'); ?></button>
        <button class="btn" type="reset" data-variant="outline">Reset</button>
    </div>
</form>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/product.form.js'); ?>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/admin/products/_form.blade.php ENDPATH**/ ?>
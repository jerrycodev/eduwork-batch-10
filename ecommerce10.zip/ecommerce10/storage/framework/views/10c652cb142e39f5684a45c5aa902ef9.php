<?php if (isset($component)) { $__componentOriginalb03144a863f57b66026dd23cf270e65d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb03144a863f57b66026dd23cf270e65d = $attributes; } ?>
<?php $component = App\View\Components\LayoutComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LayoutComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['links' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($links)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
    <div class="grid grid-cols-1 gap-6 sm:gap-8 md:grid-cols-2 lg:gap-12">

        <!-- Kiri: Galeri Gambar -->
        <div class="flex flex-col gap-4">
            <!-- Gambar Utama -->
            <div class="overflow-hidden rounded-lg bg-muted/50 aspect-square">
                <img src="<?php echo e($product->image ?? 'https://placehold.co/600x600'); ?>"
                    alt="<?php echo e($product->name ?? 'Gambar Produk'); ?>" class="w-full h-full object-cover object-center">
            </div>

            <!-- Thumbnail Placeholder (Jika ada multi-gambar) -->
            <div class="grid grid-cols-4 gap-2 sm:gap-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($i = 0; $i < 4; $i++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <button
                        class="overflow-hidden rounded-md border-2 border-transparent hover:border-primary transition-colors aspect-square bg-muted">
                        <img src="https://placehold.co/150x150" alt="Thumbnail <?php echo e($i + 1); ?>"
                            class="w-full h-full object-cover">
                    </button>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>

        <!-- Kanan: Detail Produk -->
        <div class="flex flex-col">
            <h1 class="mb-2 text-2xl font-bold tracking-tight text-foreground sm:text-3xl lg:text-4xl">
                <?php echo e($product->name ?? 'Nama Produk Berkualitas Tinggi'); ?>

            </h1>

            <!-- Harga & Badge -->
            <div class="mb-5 flex flex-wrap items-center gap-3 sm:mb-6 sm:gap-4">
                <span class="text-xl font-bold text-foreground sm:text-2xl">
                    Rp <?php echo e(number_format($product->price ?? 250000, 0, ',', '.')); ?>

                </span>
                <span class="badge" data-variant="secondary">
                    <?php echo e($product->stock > 0 ? "Stok: {$product->stock}" : "Stok Habis"); ?>

                </span>
            </div>

            <!-- Deskripsi Singkat -->
            <p class="mb-6 text-sm text-muted-foreground sm:mb-8 sm:text-base line-clamp-4">
                <?php echo e($product->description ?? 'Ini adalah deskripsi produk yang menjelaskan secara detail mengenai fitur, bahan, dan keunggulan produk ini. Dirancang menggunakan material premium untuk memastikan kenyamanan dan daya tahan jangka panjang.'); ?>

            </p>

            <!-- Form Add to Cart -->
            <form action="<?php echo e(route('cart.store', $product)); ?>" method="POST" class="mb-8">
                <?php echo csrf_field(); ?>

                <div class="flex flex-col gap-4">
                    <div class="flex items-center gap-4">
                        <label for="quantity" class="w-20 text-sm font-medium text-foreground">Jumlah</label>
                        <input type="number" id="quantity" name="quantity" value="<?php echo e(old('quantity', 1)); ?>" min="1"
                            max="<?php echo e($product->stock); ?>" required class="input w-24">
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-sm text-destructive"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <hr class="my-4 border-neutral-200">

                    <div class="flex flex-col gap-3 sm:flex-row sm:gap-4">
                        <button type="submit" class="btn min-h-11 flex-1" data-variant="default"
                            <?php if($product->stock < 1): echo 'disabled'; endif; ?>>
                            <i data-lucide="shopping-cart" class="mr-2 h-4 w-4"></i>
                            <?php echo e($product->stock > 0 ? 'Tambah ke Keranjang' : 'Stok Habis'); ?>

                        </button>
                        <button type="button" class="btn" data-variant="outline" data-size="icon"
                            aria-label="Add to wishlist">
                            <i data-lucide="heart" class="h-5 w-5"></i>
                        </button>
                    </div>
                </div>
            </form>

            <!-- Informasi Tambahan (Spesifikasi, Pengiriman) -->
            <div class="border border-neutral-200 rounded-lg bg-card">
                <div class="border-b border-neutral-200 p-4 sm:p-5">
                    <h3 class="font-medium flex items-center gap-2">
                        <i data-lucide="truck" class="h-4 w-4 text-muted-foreground"></i>
                        Informasi Pengiriman
                    </h3>
                    <p class="text-sm text-muted-foreground mt-1">Gratis ongkir untuk pesanan di atas Rp 500.000.
                        Pengiriman dalam 2-3 hari kerja.</p>
                </div>
                <div class="p-4 sm:p-5">
                    <h3 class="font-medium flex items-center gap-2">
                        <i data-lucide="shield-check" class="h-4 w-4 text-muted-foreground"></i>
                        Garansi
                    </h3>
                    <p class="text-sm text-muted-foreground mt-1">Garansi resmi 1 tahun. Retur gratis dalam 7 hari jika
                        barang tidak sesuai.</p>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb03144a863f57b66026dd23cf270e65d)): ?>
<?php $attributes = $__attributesOriginalb03144a863f57b66026dd23cf270e65d; ?>
<?php unset($__attributesOriginalb03144a863f57b66026dd23cf270e65d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb03144a863f57b66026dd23cf270e65d)): ?>
<?php $component = $__componentOriginalb03144a863f57b66026dd23cf270e65d; ?>
<?php unset($__componentOriginalb03144a863f57b66026dd23cf270e65d); ?>
<?php endif; ?>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/product/description.blade.php ENDPATH**/ ?>
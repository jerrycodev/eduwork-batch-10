<div class="bg-white">
    <header
        class="mx-auto flex min-h-16 max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:min-h-20 sm:gap-6 sm:px-6 lg:px-8">
        <a href="/">
            <h1 class="flex items-center gap-2 text-base font-bold sm:text-xl">
                
                <span>
                    <?php echo e(config('app.name')); ?>

                </span>
            </h1>
        </a>
        <nav class="nav-menu min-w-0" aria-label="Main">
            <ul class="nav-menu-list flex-wrap gap-2 sm:gap-4">
                <li class="nav-menu-item"><a class="nav-menu-link" href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="nav-menu-item"><a class="nav-menu-link" href="<?php echo e(route('shop')); ?>">Shop</a></li>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::check()): ?>
                    <li class="nav-menu-item"><a class="nav-menu-link" href="<?php echo e(route('orders.customer.index')); ?>">Orders</a></li>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
        </nav>
        <nav class="nav-menu min-w-0" aria-label="Main">
            <ul class="nav-menu-list flex-wrap gap-2 sm:gap-4">
                <li class="nav-menu-item"><a class="nav-menu-link" href="/cart" data-variant="outline"
                        data-tooltip-trigger="tooltip-profile">
                        <div class="tooltip" id="tooltip-profile" popover="hint" role="tooltip">Shopping Bag</div>
                        <i class="font-bold" data-lucide="shopping-cart"></i>
                    </a></li>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                    <li class="nav-menu-item"><a class="nav-menu-link" href="/profile" data-variant="outline"
                            data-tooltip-trigger="tooltip-profile">
                            <div class="tooltip" id="tooltip-profile" popover="hint" role="tooltip">Profile</div>
                            <i class="font-bold" data-lucide="user-round"></i>
                        </a></li>
                <?php else: ?>
                    <li class="nav-menu-item"><a class="nav-menu-link" href="/login" data-variant="outline"
                            data-tooltip-trigger="tooltip-login">
                            <div class="tooltip" id="tooltip-login" popover="hint" role="tooltip">Login</div>
                            <i class="font-bold" data-lucide="log-in"></i>
                        </a></li>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
        </nav>
    </header>

</div>
<?php /**PATH /home/user/GitHub/eduwork-batch-10/ecommerce10/resources/views/components/header.blade.php ENDPATH**/ ?>